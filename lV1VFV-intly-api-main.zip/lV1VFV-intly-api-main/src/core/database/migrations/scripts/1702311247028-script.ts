import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {

try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('52a01542-c402-466f-8653-7de572636270', '1Martina82@gmail.com', 'abduco arbitro', 'https://i.imgur.com/YfJQV5z.png', 'aveho amitto', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('a7601f0f-ad45-4e45-a2b9-eebec1de4b78', '7Jaeden_Wilkinson@gmail.com', 'laudantium tracto celer', 'https://i.imgur.com/YfJQV5z.png', 'creta denuo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('5739f567-d2e4-4f28-9c64-c2e112a105bd', '13Emory13@yahoo.com', 'adipiscor', 'https://i.imgur.com/YfJQV5z.png', 'demum depereo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('5de14220-d105-4c7b-81fb-65c5194fea0b', '19Orrin21@hotmail.com', 'voveo quibusdam', 'https://i.imgur.com/YfJQV5z.png', 'tonsor varius', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('b0de56fd-1a90-4266-94b7-7cca9aeb4209', '25Kirstin6@gmail.com', 'acervus temperantia', 'https://i.imgur.com/YfJQV5z.png', 'somniculosus temptatio', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('d6805802-8dd2-46b9-8c68-8cf912d89922', '37Talon.Buckridge15@gmail.com', 'corpus', 'https://i.imgur.com/YfJQV5z.png', 'demonstro caput solvo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('c5ce6e11-2e1e-4844-acfd-d78ca15d418c', '43Lilla12@gmail.com', 'dolores', 'https://i.imgur.com/YfJQV5z.png', 'amaritudo candidus desolo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('bc8c7749-4bc7-4dfd-b1a1-231781efcb67', '49Vince44@gmail.com', 'tertius canis', 'https://i.imgur.com/YfJQV5z.png', 'quam virtus compono', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('087a6373-a342-41d9-8112-7dc099cb2f4c', '55Shyann62@yahoo.com', 'rerum comprehendo', 'https://i.imgur.com/YfJQV5z.png', 'caecus', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('f6996463-96d3-4234-b266-ae36b495e8a2', 'tandem abduco', 'veritatis hic celebrer', 'aveho curto supellex', '64Danika54@yahoo.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9e962abd-87d0-4f92-8779-bf9d36ba0100', 'velociter tricesimus tergiversatio', 'neque adfero valde', 'adsidue concedo coniecto', '71Ernestina_Rice70@yahoo.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('8f74852b-3650-4858-8707-87c9bebdd7b2', 'officia', 'carbo', 'articulus depereo decipio', '78Shad_Brown@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('158c3b53-794d-4841-be2d-96e8fad7ac26', 'conicio bardus', 'cunctatio tutis', 'vergo', '85Pascale96@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '087a6373-a342-41d9-8112-7dc099cb2f4c');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e33e6b40-db7a-427d-bc21-1d18d17a309f', 'bis', 'cibus terra demergo', 'vix cras', '92Bertram.Sipes64@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('2b34e98e-8dd4-43f3-8d30-03f343cbe73a', 'peior ambulo', 'succurro aqua umbra', 'clementia cunabula', '99Talia_Kirlin9@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', 'c5ce6e11-2e1e-4844-acfd-d78ca15d418c');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('d9081941-d15a-486d-a9e5-0b75e4eefcbb', 'tamdiu atqui', 'abundans molestias', 'careo depereo surgo', '106Kole83@hotmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('f09ad23f-e32a-40cf-bbfd-9075193a315c', 'terra civis tristis', 'despecto', 'doloremque', '113Jeanette_Ondricka45@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '087a6373-a342-41d9-8112-7dc099cb2f4c');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('89e6c9bb-7bab-4d4a-8899-3ecc93ca414d', 'tubineus conicio', 'ab', 'curso colligo enim', '120Nathanael0@gmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('08607f69-337d-4a58-bfd5-c1db493978cd', 'ulterius adficio animi', 'suspendo', 'aveho umerus acer', '127Makenna4@hotmail.com', 'https://i.imgur.com/YfJQV5z.png', 'https://i.imgur.com/YfJQV5z.png', '5de14220-d105-4c7b-81fb-65c5194fea0b');

INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('25a14630-3c9b-4a14-a5d1-be3f1a1eac04', 'aureus cito atrocitas', 'uter', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('ce551eff-3b49-49f1-a131-46d75ca776af', 'voveo', 'aureus audax condico', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('72b55e3e-c04f-4348-9ced-399ecbbe1d58', 'adiuvo commodo thymbra', 'deporto', '5739f567-d2e4-4f28-9c64-c2e112a105bd');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('34ec5bdd-3c51-4585-90d2-15e1963eca04', 'versus incidunt cruciamentum', 'caute perspiciatis', 'd6805802-8dd2-46b9-8c68-8cf912d89922');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('3a612757-e69d-4751-b9ed-e96ebc216577', 'curis', 'spoliatio cubitum suasoria', '5739f567-d2e4-4f28-9c64-c2e112a105bd');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('b3c00bb5-8646-48eb-b9fc-4fd7b6042391', 'cursim', 'subito suscipit', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('138f2c1e-afb3-47a5-b1d9-52e6ab0cbfbf', 'demum somniculosus certus', 'comptus vinitor et', 'd6805802-8dd2-46b9-8c68-8cf912d89922');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('9fb349c2-3c15-4cc8-8e06-1fbe820a3961', 'videlicet', 'tametsi deinde', '5de14220-d105-4c7b-81fb-65c5194fea0b');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('a188258a-decb-404a-a3a9-c88cd5190275', 'volubilis', 'denique aegrus', 'd6805802-8dd2-46b9-8c68-8cf912d89922');
INSERT INTO "project" ("id", "title", "description", "userId") VALUES ('7ccc1d87-8d0c-4627-a68b-0e5c3c6be105', 'aegrus altus laudantium', 'quos vesper termes', '5739f567-d2e4-4f28-9c64-c2e112a105bd');

INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('abc98100-944f-4aff-b05a-67133abf03b6', '161Murl_Larson78@yahoo.com', 'amoveo attero nihil', '5de14220-d105-4c7b-81fb-65c5194fea0b');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('530077e5-0d23-455a-9fd9-cf9e43c0545f', '164Guillermo.Feeney@yahoo.com', 'tergum corrupti attollo', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('a5f8da25-940f-4644-9723-b1e3144e8ada', '167Vivien_Blick@hotmail.com', 'vitium denego', '5de14220-d105-4c7b-81fb-65c5194fea0b');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('2ee24b0f-06fa-4e3d-8f6b-a8b27c245628', '170Cathryn.Abshire23@yahoo.com', 'laborum adstringo canonicus', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('22996e7f-2fb1-4cb5-9121-42241deb4857', '173Manuel23@hotmail.com', 'umbra adinventitias cena', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('f5c7feb8-d4eb-4a20-9448-3d3bf33576d8', '176Lillie98@yahoo.com', 'aedificium demitto stipes', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('db3f1833-7149-4a83-9e2c-9f2e95b8402d', '179Greta.Stroman@gmail.com', 'aperte usitas vado', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('35c7de18-5356-4205-a02e-60e0b02b03f9', '182Monte_Kuhic@gmail.com', 'audeo', '52a01542-c402-466f-8653-7de572636270');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('ff90551d-ebd6-4fc1-b8b6-fde591f19a06', '185Layne.Kilback@hotmail.com', 'decretum', 'bc8c7749-4bc7-4dfd-b1a1-231781efcb67');
INSERT INTO "client" ("id", "email", "name", "userId") VALUES ('41131dad-5419-480d-bc07-24405f1840d1', '188Myles_Nolan@yahoo.com', 'constans', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('eec0a36b-aa0c-4d4f-ab12-fd3a3c414569', 'cauda sub', '7ccc1d87-8d0c-4627-a68b-0e5c3c6be105', '530077e5-0d23-455a-9fd9-cf9e43c0545f');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('dcde2afa-16bd-40a6-9c2d-4dffb56a3dd7', 'venio', 'b3c00bb5-8646-48eb-b9fc-4fd7b6042391', '22996e7f-2fb1-4cb5-9121-42241deb4857');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('8aaa1373-2cc2-4000-8bf1-6f6c63e2ae4b', 'caecus caute aer', '25a14630-3c9b-4a14-a5d1-be3f1a1eac04', '530077e5-0d23-455a-9fd9-cf9e43c0545f');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('60bd61ce-0d85-488e-9fad-f14ca3447aca', 'quia', 'ce551eff-3b49-49f1-a131-46d75ca776af', '2ee24b0f-06fa-4e3d-8f6b-a8b27c245628');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('7f755d2e-5bb2-4a23-b7f2-df2d754a27a2', 'aureus fugit vitiosus', '138f2c1e-afb3-47a5-b1d9-52e6ab0cbfbf', 'f5c7feb8-d4eb-4a20-9448-3d3bf33576d8');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('df24aa14-1ba6-4402-b390-3cf3704d05f5', 'pel', 'a188258a-decb-404a-a3a9-c88cd5190275', '2ee24b0f-06fa-4e3d-8f6b-a8b27c245628');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('7a072c9c-5c56-4ded-b553-269ac2053cbd', 'viduo depraedor', 'b3c00bb5-8646-48eb-b9fc-4fd7b6042391', 'a5f8da25-940f-4644-9723-b1e3144e8ada');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('aa8ae1fa-f221-4b46-a8b0-53d61497bd5a', 'confido cupio suscipio', 'ce551eff-3b49-49f1-a131-46d75ca776af', 'db3f1833-7149-4a83-9e2c-9f2e95b8402d');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('d2967721-f55a-4767-aad1-13f7c7d4640d', 'possimus', 'a188258a-decb-404a-a3a9-c88cd5190275', 'f5c7feb8-d4eb-4a20-9448-3d3bf33576d8');
INSERT INTO "collaboration" ("id", "status", "projectId", "clientId") VALUES ('1129e75d-e62f-4941-9fa6-848fea76308d', 'spargo desino', '34ec5bdd-3c51-4585-90d2-15e1963eca04', 'f5c7feb8-d4eb-4a20-9448-3d3bf33576d8');

INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('53cbd2f2-44a3-4bc6-badd-0223f35c77d0', 'https://i.imgur.com/YfJQV5z.png', '25a14630-3c9b-4a14-a5d1-be3f1a1eac04');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('0e6bec32-7b01-4dac-bfb5-1ad568a8a318', 'https://i.imgur.com/YfJQV5z.png', 'a188258a-decb-404a-a3a9-c88cd5190275');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('2ceb8580-5794-409f-8a44-90369fc11f55', 'https://i.imgur.com/YfJQV5z.png', '138f2c1e-afb3-47a5-b1d9-52e6ab0cbfbf');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('64a98a7b-c7a5-4050-9ed5-988bab4d8913', 'https://i.imgur.com/YfJQV5z.png', 'ce551eff-3b49-49f1-a131-46d75ca776af');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('8bd091e3-dfd6-49fb-948e-728c40b85638', 'https://i.imgur.com/YfJQV5z.png', 'b3c00bb5-8646-48eb-b9fc-4fd7b6042391');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('11ad67ee-d651-46a2-90d9-7506ca627323', 'https://i.imgur.com/YfJQV5z.png', '25a14630-3c9b-4a14-a5d1-be3f1a1eac04');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('c8b2f9bd-1ada-4441-a58e-ff9cb39fc487', 'https://i.imgur.com/YfJQV5z.png', 'a188258a-decb-404a-a3a9-c88cd5190275');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('c9db27e7-8a74-4e05-8e71-3da76d273d92', 'https://i.imgur.com/YfJQV5z.png', '138f2c1e-afb3-47a5-b1d9-52e6ab0cbfbf');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('3ed82d51-8299-456e-8387-ff9f58beec50', 'https://i.imgur.com/YfJQV5z.png', 'ce551eff-3b49-49f1-a131-46d75ca776af');
INSERT INTO "render" ("id", "imagePath", "projectId") VALUES ('15a795c0-d658-42b4-83d3-405bcbfdbd1d', 'https://i.imgur.com/YfJQV5z.png', '9fb349c2-3c15-4cc8-8e06-1fbe820a3961');

INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('63971466-8f10-49a5-a2e4-881366a89f95', 'incidunt aestivus tenetur', 'adflicto necessitatibus viridis', '0e6bec32-7b01-4dac-bfb5-1ad568a8a318', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('fa411ebd-4b2c-4c8e-8c85-127be3f687a8', 'usus terga conspergo', 'charisma casso voluptate', '8bd091e3-dfd6-49fb-948e-728c40b85638', 'd6805802-8dd2-46b9-8c68-8cf912d89922');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('337f2832-16a3-4463-aff3-9b1bbb67f330', 'arbor cerno', 'viduo venio sub', '11ad67ee-d651-46a2-90d9-7506ca627323', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('e06ffcf7-1103-4087-8b34-796bc8e051ef', 'villa', 'tantum', '3ed82d51-8299-456e-8387-ff9f58beec50', 'a7601f0f-ad45-4e45-a2b9-eebec1de4b78');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('97b3d9fa-7b8d-48e3-bc52-4b61876b80f7', 'speculum', 'inflammatio', '3ed82d51-8299-456e-8387-ff9f58beec50', '5de14220-d105-4c7b-81fb-65c5194fea0b');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('7c7f608b-7c99-4505-91c0-a1ecc325da2f', 'utpote substantia', 'conicio deficio', '64a98a7b-c7a5-4050-9ed5-988bab4d8913', 'a7601f0f-ad45-4e45-a2b9-eebec1de4b78');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('2cd73d21-5af1-4679-91df-251fddc8a595', 'depereo', 'conventus veritas', '0e6bec32-7b01-4dac-bfb5-1ad568a8a318', 'c5ce6e11-2e1e-4844-acfd-d78ca15d418c');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('7cd15444-1ebb-45b0-9a15-ec52e0aa7ec7', 'harum condico conservo', 'tubineus curvo deorsum', '11ad67ee-d651-46a2-90d9-7506ca627323', '5739f567-d2e4-4f28-9c64-c2e112a105bd');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('a1c257e8-464f-49a9-9119-d36eb1874848', 'bos usitas minus', 'nulla tondeo', '3ed82d51-8299-456e-8387-ff9f58beec50', '5de14220-d105-4c7b-81fb-65c5194fea0b');
INSERT INTO "comment" ("id", "text", "ticketStatus", "renderId", "authorId") VALUES ('1e8d84a5-87fe-4259-bb06-f98bb3b43490', 'caute', 'abduco cura', '64a98a7b-c7a5-4050-9ed5-988bab4d8913', 'd6805802-8dd2-46b9-8c68-8cf912d89922');

INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('eecc5b03-b85d-47fb-8deb-3efda1a32a00', 'strenuus vitae', 'dcde2afa-16bd-40a6-9c2d-4dffb56a3dd7', 'bc8c7749-4bc7-4dfd-b1a1-231781efcb67', 'ff90551d-ebd6-4fc1-b8b6-fde591f19a06');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('6b12a0ab-17cd-4891-b02f-2ef1c29be51c', 'strenuus perferendis theologus', 'aa8ae1fa-f221-4b46-a8b0-53d61497bd5a', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209', 'db3f1833-7149-4a83-9e2c-9f2e95b8402d');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('754f23ac-34fa-4409-abcf-340f71665fbf', 'cervus optio subseco', 'd2967721-f55a-4767-aad1-13f7c7d4640d', 'd6805802-8dd2-46b9-8c68-8cf912d89922', 'a5f8da25-940f-4644-9723-b1e3144e8ada');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('12ba32ee-dae3-4b16-9113-44d5481e7824', 'comis tertius', 'aa8ae1fa-f221-4b46-a8b0-53d61497bd5a', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209', 'a5f8da25-940f-4644-9723-b1e3144e8ada');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('bb6c8dac-6efb-4ece-b5b9-7f914115ecf1', 'aegre', '8aaa1373-2cc2-4000-8bf1-6f6c63e2ae4b', '52a01542-c402-466f-8653-7de572636270', 'ff90551d-ebd6-4fc1-b8b6-fde591f19a06');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('f76a013d-df80-493c-8256-be20673d1207', 'libero', '8aaa1373-2cc2-4000-8bf1-6f6c63e2ae4b', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209', '35c7de18-5356-4205-a02e-60e0b02b03f9');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('ba739bb4-f6dd-47b6-8d31-d18005684e3e', 'patrocinor virga', '1129e75d-e62f-4941-9fa6-848fea76308d', 'a7601f0f-ad45-4e45-a2b9-eebec1de4b78', '530077e5-0d23-455a-9fd9-cf9e43c0545f');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('82b8c362-5047-4b51-b7ae-cc25f757ad33', 'perspiciatis ter alter', 'aa8ae1fa-f221-4b46-a8b0-53d61497bd5a', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209', 'db3f1833-7149-4a83-9e2c-9f2e95b8402d');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('8b312de0-9fb8-4f5d-8fdf-6c0bf1b1cf7e', 'uxor', 'd2967721-f55a-4767-aad1-13f7c7d4640d', 'b0de56fd-1a90-4266-94b7-7cca9aeb4209', '35c7de18-5356-4205-a02e-60e0b02b03f9');
INSERT INTO "message" ("id", "content", "collaborationId", "senderId", "receiverId") VALUES ('f46460bc-42ed-4e5a-b9e8-fa34e962cf44', 'vitiosus catena', 'aa8ae1fa-f221-4b46-a8b0-53d61497bd5a', '5de14220-d105-4c7b-81fb-65c5194fea0b', '530077e5-0d23-455a-9fd9-cf9e43c0545f');

INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('69a4b89d-c958-4614-8a1a-656a1d03e5da', 'amet', '8b312de0-9fb8-4f5d-8fdf-6c0bf1b1cf7e');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('dd7013e0-ed0a-43da-a243-de5e1a6592db', 'contigo velut', '8b312de0-9fb8-4f5d-8fdf-6c0bf1b1cf7e');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('911f0db8-19eb-47b7-aaaa-f9a5f7a58499', 'taceo tolero vulgaris', '12ba32ee-dae3-4b16-9113-44d5481e7824');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('c85feea3-4d48-41f4-a9a4-89ea495b55d4', 'textor', '82b8c362-5047-4b51-b7ae-cc25f757ad33');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('c49ced9f-3573-493a-8fe6-89b6cf9ad38d', 'quo clam', 'eecc5b03-b85d-47fb-8deb-3efda1a32a00');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('36ce82c1-4c77-4155-aa0a-b6495b58b756', 'terebro carmen', '8b312de0-9fb8-4f5d-8fdf-6c0bf1b1cf7e');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('9f5d7e8b-8d84-4690-bdab-9d4584115a2a', 'canonicus balbus utrimque', 'eecc5b03-b85d-47fb-8deb-3efda1a32a00');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('7facdc1f-850e-4264-afc1-716d430a80d5', 'tempora veritas', 'f46460bc-42ed-4e5a-b9e8-fa34e962cf44');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('d79de558-0bc9-4a05-961b-04301f710eda', 'basium crepusculum', '6b12a0ab-17cd-4891-b02f-2ef1c29be51c');
INSERT INTO "feedback" ("id", "text", "messageId") VALUES ('f4b21155-9284-421e-bdb1-fd49c97ec6eb', 'desolo cibus creptio', '82b8c362-5047-4b51-b7ae-cc25f757ad33');
    `,
      )
    } catch (error) {
      // ignore
    }

}

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
