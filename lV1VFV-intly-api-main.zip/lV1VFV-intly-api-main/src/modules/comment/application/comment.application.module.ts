import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { CommentDomainModule } from '../domain'
import { CommentController } from './comment.controller'

import { RenderDomainModule } from '../../../modules/render/domain'

import { CommentByRenderController } from './commentByRender.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { CommentByUserController } from './commentByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    CommentDomainModule,

RenderDomainModule,

UserDomainModule,

],
  controllers: [
    CommentController,
    
    CommentByRenderController,
    
    CommentByUserController,
    
  ],
  providers: [],
})
export class CommentApplicationModule {}
