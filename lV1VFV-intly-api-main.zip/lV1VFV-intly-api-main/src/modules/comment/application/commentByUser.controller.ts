import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { CommentDomainFacade } from 'modules/comment/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { CommentApplicationEvent } from './comment.application.event'
import { CommentCreateDto } from './comment.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class CommentByUserController {
  constructor(
    
    private userDomainFacade: UserDomainFacade,
    
    private commentDomainFacade: CommentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/author/:authorId/comments')
  async findManyAuthorId(
    @Param('authorId') authorId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const user =
      await this.userDomainFacade.findOneByIdOrFail(
        authorId,
      )

    const items =
      await this.commentDomainFacade.findManyByAuthor(
        user,
        queryOptions,
      )

    return items
  }

  @Post('/author/:authorId/comments')
  async createByAuthorId(
    @Param('authorId') authorId: string,
    @Body() body: CommentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, authorId }

    const item = await this.commentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<CommentApplicationEvent.CommentCreated.Payload>(
      CommentApplicationEvent
        .CommentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
