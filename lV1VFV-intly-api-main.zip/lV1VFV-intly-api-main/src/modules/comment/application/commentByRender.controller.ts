import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { CommentDomainFacade } from 'modules/comment/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { CommentApplicationEvent } from './comment.application.event'
import { CommentCreateDto } from './comment.dto'

import { RenderDomainFacade } from '../../render/domain'

@Controller('/v1/renders')
export class CommentByRenderController {
  constructor(
    
    private renderDomainFacade: RenderDomainFacade,
    
    private commentDomainFacade: CommentDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/render/:renderId/comments')
  async findManyRenderId(
    @Param('renderId') renderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const render =
      await this.renderDomainFacade.findOneByIdOrFail(
        renderId,
      )

    const items =
      await this.commentDomainFacade.findManyByRender(
        render,
        queryOptions,
      )

    return items
  }

  @Post('/render/:renderId/comments')
  async createByRenderId(
    @Param('renderId') renderId: string,
    @Body() body: CommentCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, renderId }

    const item = await this.commentDomainFacade.create(valuesUpdated)

    await this.eventService.emit<CommentApplicationEvent.CommentCreated.Payload>(
      CommentApplicationEvent
        .CommentCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
