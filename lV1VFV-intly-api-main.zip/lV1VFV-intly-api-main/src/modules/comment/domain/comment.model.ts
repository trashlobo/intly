import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Render } from '../../../modules/render/domain'

import { User } from '../../../modules/user/domain'

@Entity()
export class Comment {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

text: string

@Column({})

ticketStatus: string

@Column({})

renderId: string

@ManyToOne(
  () => Render,
  parent => parent.comments,
  )
  @JoinColumn({ name: 'renderId' })

render?: Render

@Column({})

authorId: string

@ManyToOne(
  () => User,
  parent => parent.commentsAsAuthor,
  )
  @JoinColumn({ name: 'authorId' })

author?: User

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
