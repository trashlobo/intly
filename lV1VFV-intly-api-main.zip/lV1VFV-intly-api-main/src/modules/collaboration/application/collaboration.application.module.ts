import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { CollaborationDomainModule } from '../domain'
import { CollaborationController } from './collaboration.controller'

import { ProjectDomainModule } from '../../../modules/project/domain'

import { CollaborationByProjectController } from './collaborationByProject.controller'

import { ClientDomainModule } from '../../../modules/client/domain'

import { CollaborationByClientController } from './collaborationByClient.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    CollaborationDomainModule,

ProjectDomainModule,

ClientDomainModule,

],
  controllers: [
    CollaborationController,
    
    CollaborationByProjectController,
    
    CollaborationByClientController,
    
  ],
  providers: [],
})
export class CollaborationApplicationModule {}
