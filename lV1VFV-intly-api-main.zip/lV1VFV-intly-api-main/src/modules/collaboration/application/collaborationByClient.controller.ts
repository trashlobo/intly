import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { CollaborationDomainFacade } from 'modules/collaboration/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { CollaborationApplicationEvent } from './collaboration.application.event'
import { CollaborationCreateDto } from './collaboration.dto'

import { ClientDomainFacade } from '../../client/domain'

@Controller('/v1/clients')
export class CollaborationByClientController {
  constructor(
    
    private clientDomainFacade: ClientDomainFacade,
    
    private collaborationDomainFacade: CollaborationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/client/:clientId/collaborations')
  async findManyClientId(
    @Param('clientId') clientId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const client =
      await this.clientDomainFacade.findOneByIdOrFail(
        clientId,
      )

    const items =
      await this.collaborationDomainFacade.findManyByClient(
        client,
        queryOptions,
      )

    return items
  }

  @Post('/client/:clientId/collaborations')
  async createByClientId(
    @Param('clientId') clientId: string,
    @Body() body: CollaborationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, clientId }

    const item = await this.collaborationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<CollaborationApplicationEvent.CollaborationCreated.Payload>(
      CollaborationApplicationEvent
        .CollaborationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
