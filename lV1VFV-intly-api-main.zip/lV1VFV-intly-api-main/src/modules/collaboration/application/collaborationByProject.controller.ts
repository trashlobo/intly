import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { CollaborationDomainFacade } from 'modules/collaboration/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { CollaborationApplicationEvent } from './collaboration.application.event'
import { CollaborationCreateDto } from './collaboration.dto'

import { ProjectDomainFacade } from '../../project/domain'

@Controller('/v1/projects')
export class CollaborationByProjectController {
  constructor(
    
    private projectDomainFacade: ProjectDomainFacade,
    
    private collaborationDomainFacade: CollaborationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/project/:projectId/collaborations')
  async findManyProjectId(
    @Param('projectId') projectId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const project =
      await this.projectDomainFacade.findOneByIdOrFail(
        projectId,
      )

    const items =
      await this.collaborationDomainFacade.findManyByProject(
        project,
        queryOptions,
      )

    return items
  }

  @Post('/project/:projectId/collaborations')
  async createByProjectId(
    @Param('projectId') projectId: string,
    @Body() body: CollaborationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, projectId }

    const item = await this.collaborationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<CollaborationApplicationEvent.CollaborationCreated.Payload>(
      CollaborationApplicationEvent
        .CollaborationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
