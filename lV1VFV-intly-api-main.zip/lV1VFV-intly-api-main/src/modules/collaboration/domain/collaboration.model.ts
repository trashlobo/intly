import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Project } from '../../../modules/project/domain'

import { Client } from '../../../modules/client/domain'

import { Message } from '../../../modules/message/domain'

@Entity()
export class Collaboration {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

status: string

@Column({})

projectId: string

@ManyToOne(
  () => Project,
  parent => parent.collaborations,
  )
  @JoinColumn({ name: 'projectId' })

project?: Project

@Column({})

clientId: string

@ManyToOne(
  () => Client,
  parent => parent.collaborations,
  )
  @JoinColumn({ name: 'clientId' })

client?: Client

@OneToMany(
  () => Message,
  child => child.collaboration,
  )

messages?: Message[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
