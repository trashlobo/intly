import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Message } from '../../../modules/message/domain'

@Entity()
export class Feedback {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

text: string

@Column({})

messageId: string

@ManyToOne(
  () => Message,
  parent => parent.feedbacks,
  )
  @JoinColumn({ name: 'messageId' })

message?: Message

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
