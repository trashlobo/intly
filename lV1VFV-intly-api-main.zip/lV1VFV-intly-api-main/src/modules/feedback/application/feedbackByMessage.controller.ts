import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { FeedbackDomainFacade } from 'modules/feedback/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { FeedbackApplicationEvent } from './feedback.application.event'
import { FeedbackCreateDto } from './feedback.dto'

import { MessageDomainFacade } from '../../message/domain'

@Controller('/v1/messages')
export class FeedbackByMessageController {
  constructor(
    
    private messageDomainFacade: MessageDomainFacade,
    
    private feedbackDomainFacade: FeedbackDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/message/:messageId/feedbacks')
  async findManyMessageId(
    @Param('messageId') messageId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const message =
      await this.messageDomainFacade.findOneByIdOrFail(
        messageId,
      )

    const items =
      await this.feedbackDomainFacade.findManyByMessage(
        message,
        queryOptions,
      )

    return items
  }

  @Post('/message/:messageId/feedbacks')
  async createByMessageId(
    @Param('messageId') messageId: string,
    @Body() body: FeedbackCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, messageId }

    const item = await this.feedbackDomainFacade.create(valuesUpdated)

    await this.eventService.emit<FeedbackApplicationEvent.FeedbackCreated.Payload>(
      FeedbackApplicationEvent
        .FeedbackCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
