import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { FeedbackDomainModule } from '../domain'
import { FeedbackController } from './feedback.controller'

import { MessageDomainModule } from '../../../modules/message/domain'

import { FeedbackByMessageController } from './feedbackByMessage.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    FeedbackDomainModule,

MessageDomainModule,

],
  controllers: [
    FeedbackController,
    
    FeedbackByMessageController,
    
  ],
  providers: [],
})
export class FeedbackApplicationModule {}
