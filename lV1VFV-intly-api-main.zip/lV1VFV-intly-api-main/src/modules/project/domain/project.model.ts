import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Collaboration } from '../../../modules/collaboration/domain'

import { Render } from '../../../modules/render/domain'

@Entity()
export class Project {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

title: string

@Column({"nullable":true})

description?: string

@Column({})

userId: string

@ManyToOne(
  () => User,
  parent => parent.projects,
  )
  @JoinColumn({ name: 'userId' })

user?: User

@OneToMany(
  () => Collaboration,
  child => child.project,
  )

collaborations?: Collaboration[]

@OneToMany(
  () => Render,
  child => child.project,
  )

renders?: Render[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
