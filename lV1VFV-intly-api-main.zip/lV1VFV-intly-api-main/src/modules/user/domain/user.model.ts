import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Notification } from '../../../modules/notification/domain'

import { Project } from '../../../modules/project/domain'

import { Client } from '../../../modules/client/domain'

import { Comment } from '../../../modules/comment/domain'

import { Message } from '../../../modules/message/domain'

export enum UserStatus {
  VERIFIED = 'VERIFIED',
  CREATED = 'CREATED',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ unique: true })
  email: string

  @Column()
  name: string

  @Column({ nullable: true })
  pictureUrl?: string

  @Column({ select: false, nullable: true })
  password: string

  @Column({ enum: UserStatus, default: UserStatus.CREATED })
  status: UserStatus

@OneToMany(
  () => Project,
  child => child.user,
  )

projects?: Project[]

@OneToMany(
  () => Client,
  child => child.user,
  )

clients?: Client[]

@OneToMany(
  () => Comment,
  child => child.author,
  )

commentsAsAuthor?: Comment[]

@OneToMany(
  () => Message,
  child => child.sender,
  )

messagesAsSender?: Message[]

@OneToMany(() => Notification, notification => notification.user)
  notifications?: Notification[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
