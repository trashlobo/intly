import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Message } from './message.model'

import { Collaboration } from '../../collaboration/domain'

import { User } from '../../user/domain'

import { Client } from '../../client/domain'

@Injectable()
export class MessageDomainFacade {
  constructor(
    @InjectRepository(Message)
    private repository: Repository<Message>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<Message>,
  ): Promise<Message> {
    return this.repository.save(values)
  }

  async update(
    item: Message,
    values: Partial<Message>,
  ): Promise<Message> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Message): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Message> = {},
  ): Promise<Message[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Message> = {},
  ): Promise<Message> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

async findManyByCollaboration(
    collaboration: Collaboration,
    queryOptions: RequestHelper.QueryOptions<Message> = {},
  ): Promise<Message[]> {
    if (!collaboration) {
      this.databaseHelper.invalidQueryWhere('collaboration')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        collaborationId: collaboration.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

async findManyBySender(
    sender: User,
    queryOptions: RequestHelper.QueryOptions<Message> = {},
  ): Promise<Message[]> {
    if (!sender) {
      this.databaseHelper.invalidQueryWhere('sender')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        senderId: sender.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

async findManyByReceiver(
    receiver: Client,
    queryOptions: RequestHelper.QueryOptions<Message> = {},
  ): Promise<Message[]> {
    if (!receiver) {
      this.databaseHelper.invalidQueryWhere('receiver')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        receiverId: receiver.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

}
