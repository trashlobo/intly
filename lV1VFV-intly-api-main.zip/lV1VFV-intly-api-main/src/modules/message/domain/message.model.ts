import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Collaboration } from '../../../modules/collaboration/domain'

import { User } from '../../../modules/user/domain'

import { Client } from '../../../modules/client/domain'

import { Feedback } from '../../../modules/feedback/domain'

@Entity()
export class Message {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

content: string

@Column({})

collaborationId: string

@ManyToOne(
  () => Collaboration,
  parent => parent.messages,
  )
  @JoinColumn({ name: 'collaborationId' })

collaboration?: Collaboration

@Column({})

senderId: string

@ManyToOne(
  () => User,
  parent => parent.messagesAsSender,
  )
  @JoinColumn({ name: 'senderId' })

sender?: User

@Column({})

receiverId: string

@ManyToOne(
  () => Client,
  parent => parent.messagesAsReceiver,
  )
  @JoinColumn({ name: 'receiverId' })

receiver?: Client

@OneToMany(
  () => Feedback,
  child => child.message,
  )

feedbacks?: Feedback[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
