import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { MessageDomainFacade } from 'modules/message/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { MessageApplicationEvent } from './message.application.event'
import { MessageCreateDto } from './message.dto'

import { CollaborationDomainFacade } from '../../collaboration/domain'

@Controller('/v1/collaborations')
export class MessageByCollaborationController {
  constructor(
    
    private collaborationDomainFacade: CollaborationDomainFacade,
    
    private messageDomainFacade: MessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/collaboration/:collaborationId/messages')
  async findManyCollaborationId(
    @Param('collaborationId') collaborationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const collaboration =
      await this.collaborationDomainFacade.findOneByIdOrFail(
        collaborationId,
      )

    const items =
      await this.messageDomainFacade.findManyByCollaboration(
        collaboration,
        queryOptions,
      )

    return items
  }

  @Post('/collaboration/:collaborationId/messages')
  async createByCollaborationId(
    @Param('collaborationId') collaborationId: string,
    @Body() body: MessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, collaborationId }

    const item = await this.messageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MessageApplicationEvent.MessageCreated.Payload>(
      MessageApplicationEvent
        .MessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
