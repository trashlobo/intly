import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { MessageDomainModule } from '../domain'
import { MessageController } from './message.controller'

import { CollaborationDomainModule } from '../../../modules/collaboration/domain'

import { MessageByCollaborationController } from './messageByCollaboration.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { MessageByUserController } from './messageByUser.controller'

import { ClientDomainModule } from '../../../modules/client/domain'

import { MessageByClientController } from './messageByClient.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MessageDomainModule,

CollaborationDomainModule,

UserDomainModule,

ClientDomainModule,

],
  controllers: [
    MessageController,
    
    MessageByCollaborationController,
    
    MessageByUserController,
    
    MessageByClientController,
    
  ],
  providers: [],
})
export class MessageApplicationModule {}
