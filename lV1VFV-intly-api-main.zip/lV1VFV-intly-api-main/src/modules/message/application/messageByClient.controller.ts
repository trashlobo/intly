import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { MessageDomainFacade } from 'modules/message/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { MessageApplicationEvent } from './message.application.event'
import { MessageCreateDto } from './message.dto'

import { ClientDomainFacade } from '../../client/domain'

@Controller('/v1/clients')
export class MessageByClientController {
  constructor(
    
    private clientDomainFacade: ClientDomainFacade,
    
    private messageDomainFacade: MessageDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/receiver/:receiverId/messages')
  async findManyReceiverId(
    @Param('receiverId') receiverId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const client =
      await this.clientDomainFacade.findOneByIdOrFail(
        receiverId,
      )

    const items =
      await this.messageDomainFacade.findManyByReceiver(
        client,
        queryOptions,
      )

    return items
  }

  @Post('/receiver/:receiverId/messages')
  async createByReceiverId(
    @Param('receiverId') receiverId: string,
    @Body() body: MessageCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, receiverId }

    const item = await this.messageDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MessageApplicationEvent.MessageCreated.Payload>(
      MessageApplicationEvent
        .MessageCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
