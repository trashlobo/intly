import { Module } from '@nestjs/common'
import { SocketModule } from 'libraries/socket'
import { AuthorizationDomainModule } from 'modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationProjectSubscriber } from './subscribers/notification.project.subscriber'

import { NotificationClientSubscriber } from './subscribers/notification.client.subscriber'

import { NotificationCollaborationSubscriber } from './subscribers/notification.collaboration.subscriber'

import { NotificationRenderSubscriber } from './subscribers/notification.render.subscriber'

import { NotificationCommentSubscriber } from './subscribers/notification.comment.subscriber'

import { NotificationMessageSubscriber } from './subscribers/notification.message.subscriber'

import { NotificationFeedbackSubscriber } from './subscribers/notification.feedback.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [

NotificationProjectSubscriber,

NotificationClientSubscriber,

NotificationCollaborationSubscriber,

NotificationRenderSubscriber,

NotificationCommentSubscriber,

NotificationMessageSubscriber,

NotificationFeedbackSubscriber,

],
  exports: [],
})
export class NotificationInfrastructureModule {}
