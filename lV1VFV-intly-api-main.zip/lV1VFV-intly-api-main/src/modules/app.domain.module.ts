import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { ProjectDomainModule } from './project/domain'

import { ClientDomainModule } from './client/domain'

import { CollaborationDomainModule } from './collaboration/domain'

import { RenderDomainModule } from './render/domain'

import { CommentDomainModule } from './comment/domain'

import { MessageDomainModule } from './message/domain'

import { FeedbackDomainModule } from './feedback/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

ProjectDomainModule,

ClientDomainModule,

CollaborationDomainModule,

RenderDomainModule,

CommentDomainModule,

MessageDomainModule,

FeedbackDomainModule,

],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
