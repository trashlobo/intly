import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class RenderCreateDto {

@IsString()

@IsNotEmpty()
  imagePath: string

@IsString()

@IsOptional()
  projectId?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

}

export class RenderUpdateDto {

@IsString()

@IsOptional()
  imagePath?: string

@IsString()

@IsOptional()
  projectId?: string

@IsString()

@IsOptional()
  dateCreated?: string

@IsString()

@IsOptional()
  dateDeleted?: string

@IsString()

@IsOptional()
  dateUpdated?: string

}
