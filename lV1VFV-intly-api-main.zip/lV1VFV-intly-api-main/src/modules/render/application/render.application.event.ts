export namespace RenderApplicationEvent {
  export namespace RenderCreated {
    export const key = 'render.application.render.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
