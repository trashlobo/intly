import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { RenderDomainFacade } from 'modules/render/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RenderApplicationEvent } from './render.application.event'
import { RenderCreateDto } from './render.dto'

import { ProjectDomainFacade } from '../../project/domain'

@Controller('/v1/projects')
export class RenderByProjectController {
  constructor(
    
    private projectDomainFacade: ProjectDomainFacade,
    
    private renderDomainFacade: RenderDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/project/:projectId/renders')
  async findManyProjectId(
    @Param('projectId') projectId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const project =
      await this.projectDomainFacade.findOneByIdOrFail(
        projectId,
      )

    const items =
      await this.renderDomainFacade.findManyByProject(
        project,
        queryOptions,
      )

    return items
  }

  @Post('/project/:projectId/renders')
  async createByProjectId(
    @Param('projectId') projectId: string,
    @Body() body: RenderCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, projectId }

    const item = await this.renderDomainFacade.create(valuesUpdated)

    await this.eventService.emit<RenderApplicationEvent.RenderCreated.Payload>(
      RenderApplicationEvent
        .RenderCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
