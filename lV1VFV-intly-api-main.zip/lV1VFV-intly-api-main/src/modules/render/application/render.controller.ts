import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Render,
  RenderDomainFacade,
} from 'modules/render/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { RenderApplicationEvent } from './render.application.event'
import {
  RenderCreateDto,
  RenderUpdateDto,
} from './render.dto'

@Controller('/v1/renders')
export class RenderController {
  constructor(
    private eventService: EventService,
    private renderDomainFacade: RenderDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.renderDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: RenderCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.renderDomainFacade.create(body)

    await this.eventService.emit<RenderApplicationEvent.RenderCreated.Payload>(
      RenderApplicationEvent
        .RenderCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:renderId')
  async findOne(
    @Param('renderId') renderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.renderDomainFacade.findOneByIdOrFail(
        renderId,
        queryOptions,
      )

    return item
  }

  @Patch('/:renderId')
  async update(
    @Param('renderId') renderId: string,
    @Body() body: RenderUpdateDto,
  ) {
    const item =
      await this.renderDomainFacade.findOneByIdOrFail(
        renderId,
      )

    const itemUpdated = await this.renderDomainFacade.update(
      item,
      body as Partial<Render>,
    )
    return itemUpdated
  }

  @Delete('/:renderId')
  async delete(@Param('renderId') renderId: string) {
    const item =
      await this.renderDomainFacade.findOneByIdOrFail(
        renderId,
      )

    await this.renderDomainFacade.delete(item)

    return item
  }
}
