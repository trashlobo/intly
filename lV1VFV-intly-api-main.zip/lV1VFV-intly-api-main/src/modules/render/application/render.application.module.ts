import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { RenderDomainModule } from '../domain'
import { RenderController } from './render.controller'

import { ProjectDomainModule } from '../../../modules/project/domain'

import { RenderByProjectController } from './renderByProject.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    RenderDomainModule,

ProjectDomainModule,

],
  controllers: [
    RenderController,
    
    RenderByProjectController,
    
  ],
  providers: [],
})
export class RenderApplicationModule {}
