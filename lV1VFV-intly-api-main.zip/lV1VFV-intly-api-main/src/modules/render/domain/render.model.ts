import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Project } from '../../../modules/project/domain'

import { Comment } from '../../../modules/comment/domain'

@Entity()
export class Render {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

imagePath: string

@Column({})

projectId: string

@ManyToOne(
  () => Project,
  parent => parent.renders,
  )
  @JoinColumn({ name: 'projectId' })

project?: Project

@OneToMany(
  () => Comment,
  child => child.render,
  )

comments?: Comment[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
