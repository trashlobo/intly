import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { Render } from './render.model'

import { Project } from '../../project/domain'

@Injectable()
export class RenderDomainFacade {
  constructor(
    @InjectRepository(Render)
    private repository: Repository<Render>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<Render>,
  ): Promise<Render> {
    return this.repository.save(values)
  }

  async update(
    item: Render,
    values: Partial<Render>,
  ): Promise<Render> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: Render): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<Render> = {},
  ): Promise<Render[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<Render> = {},
  ): Promise<Render> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

async findManyByProject(
    project: Project,
    queryOptions: RequestHelper.QueryOptions<Render> = {},
  ): Promise<Render[]> {
    if (!project) {
      this.databaseHelper.invalidQueryWhere('project')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        projectId: project.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

}
