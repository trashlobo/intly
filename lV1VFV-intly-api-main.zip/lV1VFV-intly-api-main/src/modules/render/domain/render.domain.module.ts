import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { RenderDomainFacade } from './render.domain.facade'
import { Render } from './render.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Render]),
    DatabaseHelperModule,
  ],
  providers: [
    RenderDomainFacade,
    RenderDomainFacade,
  ],
  exports: [RenderDomainFacade],
})
export class RenderDomainModule {}
