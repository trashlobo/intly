import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ClientDomainFacade } from './client.domain.facade'
import { Client } from './client.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([Client]),
    DatabaseHelperModule,
  ],
  providers: [
    ClientDomainFacade,
    ClientDomainFacade,
  ],
  exports: [ClientDomainFacade],
})
export class ClientDomainModule {}
