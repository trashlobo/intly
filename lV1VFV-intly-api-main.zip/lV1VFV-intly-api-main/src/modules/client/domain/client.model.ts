import { ColumnNumeric } from 'core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Collaboration } from '../../../modules/collaboration/domain'

import { Message } from '../../../modules/message/domain'

@Entity()
export class Client {

@PrimaryGeneratedColumn('uuid')

id: string

@Column({})

email: string

@Column({})

name: string

@Column({})

userId: string

@ManyToOne(
  () => User,
  parent => parent.clients,
  )
  @JoinColumn({ name: 'userId' })

user?: User

@OneToMany(
  () => Collaboration,
  child => child.client,
  )

collaborations?: Collaboration[]

@OneToMany(
  () => Message,
  child => child.receiver,
  )

messagesAsReceiver?: Message[]

@CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
