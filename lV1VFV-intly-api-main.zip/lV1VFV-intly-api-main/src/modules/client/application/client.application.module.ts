import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from 'modules/authentication/domain'
import { ClientDomainModule } from '../domain'
import { ClientController } from './client.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ClientByUserController } from './clientByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ClientDomainModule,

UserDomainModule,

],
  controllers: [
    ClientController,
    
    ClientByUserController,
    
  ],
  providers: [],
})
export class ClientApplicationModule {}
