import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from 'libraries/event'
import {
  Client,
  ClientDomainFacade,
} from 'modules/client/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ClientApplicationEvent } from './client.application.event'
import {
  ClientCreateDto,
  ClientUpdateDto,
} from './client.dto'

@Controller('/v1/clients')
export class ClientController {
  constructor(
    private eventService: EventService,
    private clientDomainFacade: ClientDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.clientDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: ClientCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.clientDomainFacade.create(body)

    await this.eventService.emit<ClientApplicationEvent.ClientCreated.Payload>(
      ClientApplicationEvent
        .ClientCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:clientId')
  async findOne(
    @Param('clientId') clientId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item =
      await this.clientDomainFacade.findOneByIdOrFail(
        clientId,
        queryOptions,
      )

    return item
  }

  @Patch('/:clientId')
  async update(
    @Param('clientId') clientId: string,
    @Body() body: ClientUpdateDto,
  ) {
    const item =
      await this.clientDomainFacade.findOneByIdOrFail(
        clientId,
      )

    const itemUpdated = await this.clientDomainFacade.update(
      item,
      body as Partial<Client>,
    )
    return itemUpdated
  }

  @Delete('/:clientId')
  async delete(@Param('clientId') clientId: string) {
    const item =
      await this.clientDomainFacade.findOneByIdOrFail(
        clientId,
      )

    await this.clientDomainFacade.delete(item)

    return item
  }
}
