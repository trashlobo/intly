export namespace ClientApplicationEvent {
  export namespace ClientCreated {
    export const key = 'client.application.client.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
