import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from 'helpers/request'
import { EventService } from 'libraries/event'
import { ClientDomainFacade } from 'modules/client/domain'
import { AuthenticationDomainFacade } from 'modules/authentication/domain'
import { ClientApplicationEvent } from './client.application.event'
import { ClientCreateDto } from './client.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class ClientByUserController {
  constructor(
    
    private userDomainFacade: UserDomainFacade,
    
    private clientDomainFacade: ClientDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

@Get('/user/:userId/clients')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const user =
      await this.userDomainFacade.findOneByIdOrFail(
        userId,
      )

    const items =
      await this.clientDomainFacade.findManyByUser(
        user,
        queryOptions,
      )

    return items
  }

  @Post('/user/:userId/clients')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: ClientCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.clientDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClientApplicationEvent.ClientCreated.Payload>(
      ClientApplicationEvent
        .ClientCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
  
}
